// lib/routing/app_router.dart
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../core/theme/app_colors.dart';
import '../screens/auth/login_screen.dart';
import '../screens/auth/register_screen.dart';
import '../screens/home/home_screen.dart';
import '../screens/learning/learning_completion_screen.dart';
import '../screens/learning/learning_screen.dart';
import '../screens/progress/leaderboard_screen.dart';
import '../screens/progress/progress_screen.dart';
import '../screens/settings/settings_screen.dart';
import '../screens/splash/splash_screen.dart';
import '../screens/subject/subject_lessons_screen.dart';
import '../services/local_storage_service.dart';

class AppRouter {
  // أسماء الروابط (Named Routes) - لتسهيل الاستخدام
  static const String splash = '/';
  static const String login = '/login';
  static const String register = '/register';
  static const String home = '/home';
  static const String subjectLessons = '/subject-lessons';
  static const String lesson = '/lesson';
  static const String lessonComplete = '/lesson-complete';
  static const String progress = '/progress';
  static const String leaderboard = '/leaderboard';
  static const String settings = '/settings';

  static GoRouter router = GoRouter(
    initialLocation: splash,
    debugLogDiagnostics: true,

    // Redirect Logic (الحماية)
    redirect: (context, state) {
      final isLoggedIn = LocalStorageService().isLoggedIn;

      final bool isAuthRoute =
          state.matchedLocation == login || state.matchedLocation == register;

      // غير مسجل → يروح للـ login (ما عدا Splash)
      if (!isLoggedIn && !isAuthRoute && state.matchedLocation != splash) {
        return login;
      }

      // مسجل → يروح للـ home إذا حاول يدخل صفحات التسجيل
      if (isLoggedIn && isAuthRoute) {
        return home;
      }

      return null;
    },

    routes: [
      // Splash
      GoRoute(path: splash, builder: (context, state) => const SplashScreen()),

      // Auth
      GoRoute(path: login, builder: (context, state) => const LoginScreen()),
      GoRoute(
        path: register,
        builder: (context, state) => const RegisterScreen(),
      ),

      // Main Screens
      GoRoute(path: home, builder: (context, state) => const HomeScreen()),

      // Subject Lessons
      GoRoute(
        path: '$subjectLessons/:subjectId',
        builder: (context, state) {
          final subjectId = int.parse(state.pathParameters['subjectId']!);
          final extra = state.extra as Map<String, dynamic>? ?? {};

          return SubjectLessonsScreen(
            subjectId: subjectId,
            subjectName: extra['subjectName'] as String? ?? 'المادة',
            subjectColor: extra['subjectColor'] as Color? ?? AppColors.primary,
          );
        },
      ),

      // Learning Screen
      GoRoute(
        path: '$lesson/:lessonId',
        builder: (context, state) {
          final lessonId = int.parse(state.pathParameters['lessonId']!);
          final extra = state.extra as Map<String, dynamic>? ?? {};

          return LearningScreen(
            lessonId: lessonId,
            lessonTitle: extra['lessonTitle'] as String? ?? 'الدرس',
          );
        },
      ),

      // Learning Completion
      GoRoute(
        path: '$lessonComplete/:lessonId',
        builder: (context, state) {
          final lessonId = int.parse(state.pathParameters['lessonId']!);
          final extra = state.extra as Map<String, dynamic>? ?? {};

          return LearningCompletionScreen(
            lessonId: lessonId,
            lessonTitle: extra['lessonTitle'] as String? ?? 'الدرس',
          );
        },
      ),

      GoRoute(
        path: progress,
        builder: (context, state) => const ProgressScreen(),
      ),

      GoRoute(
        path: leaderboard,
        builder: (context, state) => const LeaderboardScreen(),
      ),

      GoRoute(
        path: settings,
        builder: (context, state) => const SettingsScreen(),
      ),
    ],
  );
}
