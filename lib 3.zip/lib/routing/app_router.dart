// lib/routing/app_router.dart
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../screens/splash/splash_screen.dart';
import '../screens/auth/login_screen.dart';
import '../screens/auth/register_screen.dart';
import '../screens/home/home_screen.dart';
import '../screens/subject/subject_lessons_screen.dart';
import '../screens/learning/learning_screen.dart';
import '../screens/learning/learning_completion_screen.dart';
import '../screens/progress/progress_screen.dart';
import '../screens/progress/leaderboard_screen.dart';
import '../screens/settings/settings_screen.dart';

import '../services/local_storage_service.dart';

class AppRouter {
  static final GoRouter router = GoRouter(
    initialLocation: '/',
    debugLogDiagnostics: true,

    redirect: (context, state) {
      final isLoggedIn = LocalStorageService().isLoggedIn;

      final bool isAuthRoute =
          state.matchedLocation == '/login' ||
          state.matchedLocation == '/register';

      if (!isLoggedIn && !isAuthRoute && state.matchedLocation != '/') {
        return '/login';
      }

      if (isLoggedIn && isAuthRoute) {
        return '/home';
      }

      return null;
    },

    routes: [
      GoRoute(path: '/', builder: (context, state) => const SplashScreen()),
      GoRoute(path: '/login', builder: (context, state) => const LoginScreen()),
      GoRoute(
        path: '/register',
        builder: (context, state) => const RegisterScreen(),
      ),
      GoRoute(path: '/home', builder: (context, state) => const HomeScreen()),

      GoRoute(
        path: '/subject-lessons/:subjectId',
        builder: (context, state) {
          final subjectId = int.parse(state.pathParameters['subjectId']!);
          final extra = state.extra as Map<String, dynamic>? ?? {};
          return SubjectLessonsScreen(
            subjectId: subjectId,
            subjectName: extra['subjectName'] as String? ?? 'المادة',
            subjectColor: extra['subjectColor'] as Color? ?? Colors.blue,
          );
        },
      ),

      GoRoute(
        path: '/lesson/:lessonId',
        builder: (context, state) {
          final lessonId = int.parse(state.pathParameters['lessonId']!);
          final extra = state.extra as Map<String, dynamic>? ?? {};
          return LearningScreen(
            lessonId: lessonId,
            lessonTitle: extra['lessonTitle'] as String? ?? 'الدرس',
          );
        },
      ),

      GoRoute(
        path: '/lesson-complete/:lessonId',
        builder: (context, state) {
          final lessonId = int.parse(state.pathParameters['lessonId']!);
          final extra = state.extra as Map<String, dynamic>? ?? {};
          return LearningCompletionScreen(
            lessonId: lessonId,
            lessonTitle: extra['lessonTitle'] as String? ?? 'الدرس',
          );
        },
      ),

      GoRoute(
        path: '/progress',
        builder: (context, state) => const ProgressScreen(),
      ),
      GoRoute(
        path: '/leaderboard',
        builder: (context, state) => const LeaderboardScreen(),
      ),
      GoRoute(
        path: '/settings',
        builder: (context, state) => const SettingsScreen(),
      ),
    ],
  );
}
